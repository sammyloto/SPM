<?php

define("MYSQL_HOSTNAME", "localhost");
define("MYSQL_DATABASE", "dabhands_spm");
define("MYSQL_USERNAME", "dabhands_spm");
define("MYSQL_PASSWORD", "AUE[{MSWv}bz");
