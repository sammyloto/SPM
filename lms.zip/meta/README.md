# Library Management System

<details><summary>Home Screen</summary>

  ![](screencapture-library-local-sign-in-1450375374680.png?raw=true )
</details>

<details><summary>Student Panel</summary>

  ![](screencapture-library-local-book-1450375417998.png?raw=true )
  ![](screencapture-library-local-student-registration-1450375390857.png?raw=true )
</details>

<details><summary>Librarian Panel</summary>

  ![](screencapture-library-local-1450375427449.png?raw=true )
  ![](screencapture-library-local-1450375550068.png?raw=true )
  ![](screencapture-library-local-1450375572059.png?raw=true )
</details>

<details><summary>Add New Books to library</summary>

  ![](screencapture-library-local-add-books-1450375474305.png?raw=true )
</details>

<details><summary>Manage Students</summary>

  ![](screencapture-library-local-students-for-approval-1450375439861.png?raw=true )
  ![](screencapture-library-local-registered-students-1450375458648.png?raw=true )
</details>

<details><summary>Issue Books and logs</summary>

  ![](screencapture-library-local-issue-return-1450375480498.png?raw=true )
  ![](screencapture-library-local-currently-issued-1450375536118.png?raw=true )
</details>
